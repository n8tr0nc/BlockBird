document.addEventListener('DOMContentLoaded', () => {
    if (typeof initializeTranslations === 'function') {
      initializeTranslations();
    }
  });
  